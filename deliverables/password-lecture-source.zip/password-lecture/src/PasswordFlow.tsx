import React from 'react';

type PasswordFlowProps = {seconds: number};

const blue = '#1466ac';
const teal = '#008b89';
const green = '#17804f';
const muted = '#a8c5d5';
const clamp = (value: number) => Math.max(0, Math.min(1, value));

/** Deterministic, branched validation loop; seconds are relative to 67s. */
export const PasswordFlow: React.FC<PasswordFlowProps> = ({seconds}) => {
  const time = Math.max(0, seconds);
  const accepted = time >= 6.5;
  const intervals = {
    input: [[0, 0.85], [2.4, 3.25], [4.8, 5.65]],
    validate: [[0.85, 1.55], [3.25, 3.95], [5.65, 6.5]],
    retry: [[1.55, 2.4], [3.95, 4.8]],
  };
  const highlight = (name: keyof typeof intervals) => accepted ? 0 : Math.max(
    ...intervals[name].map(([start, end]) =>
      clamp((time - start + 0.1) / 0.2) * clamp((end - time + 0.1) / 0.2)),
  );
  const validProgress = clamp((time - 6.15) / 0.35);
  const inputStrength = highlight('input');
  const validateStrength = highlight('validate');
  const retryStrength = highlight('retry');
  const firstArrow = Math.max(inputStrength * 0.65, validateStrength);
  const invalidArrow = Math.max(retryStrength, validateStrength * (time < 5 ? 0.6 : 0));

  const node = (
    x: number, y: number, width: number, height: number,
    title: string, detail: string | undefined, strength: number, success = false,
  ) => <g>
    <rect x={x} y={y} width={width} height={height} rx={18}
      fill={success ? '#effbf4' : '#f4fbff'} stroke="#c7e4ec" strokeWidth={2}/>
    <rect x={x} y={y} width={width} height={height} rx={18}
      fill={success ? '#e0f7e9' : '#e3f7f5'} stroke={success ? green : teal}
      strokeWidth={4} opacity={strength}/>
    <text x={x + width / 2} y={y + (detail ? 43 : height / 2 + 10)}
      textAnchor="middle" fill={success ? green : blue} fontSize={30} fontWeight={700}>
      {title}
    </text>
    {detail && <text x={x + width / 2} y={y + 78} textAnchor="middle"
      fill="#42677b" fontSize={24}>{detail}</text>}
  </g>;

  const arrow = (path: string, strength: number, success = false) => <g>
    <path d={path} fill="none" stroke={muted} strokeWidth={4}
      strokeLinecap="round" strokeLinejoin="round" markerEnd="url(#password-flow-muted)"/>
    <path d={path} fill="none" stroke={success ? green : teal} strokeWidth={5}
      strokeLinecap="round" strokeLinejoin="round" strokeDasharray="12 10"
      strokeDashoffset={-time * 60} opacity={strength}
      markerEnd={success ? 'url(#password-flow-green)' : 'url(#password-flow-teal)'}/>
  </g>;

  return <svg viewBox="0 0 1040 440" width="100%" height="100%"
    role="img" aria-label="Enter a password, validate all requirements, retry invalid passwords, and accept a valid password."
    style={{display: 'block', fontFamily: 'Arial, sans-serif'}}>
    <defs>
      {[['muted', muted], ['teal', teal], ['green', green]].map(([name, color]) =>
        <marker key={name} id={`password-flow-${name}`} viewBox="0 0 10 10"
          refX={9} refY={5} markerWidth={8} markerHeight={8} orient="auto-start-reverse"
          markerUnits="userSpaceOnUse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill={color}/>
        </marker>)}
    </defs>

    {arrow('M 340 105 H 420', firstArrow)}
    {arrow('M 690 105 H 790', validProgress, true)}
    {arrow('M 555 160 V 252', invalidArrow)}
    {arrow('M 420 298 H 190 V 160', retryStrength)}

    <text x={740} y={77} textAnchor="middle" fill={green} fontSize={24} fontWeight={700}>Valid</text>
    <text x={615} y={213} textAnchor="middle" fill={teal} fontSize={24} fontWeight={700}>Invalid</text>

    {node(40, 50, 300, 110, 'Enter password', undefined, inputStrength)}
    {node(420, 50, 270, 110, 'Validate', 'All 5 requirements', validateStrength)}
    {node(790, 50, 220, 110, '✓ Accepted', undefined, validProgress, true)}
    {node(420, 252, 270, 92, 'Try again', undefined, retryStrength)}

    <text x={190} y={346} textAnchor="middle" fill={teal} fontSize={24}>Retry if invalid</text>
    <text x={520} y={410} textAnchor="middle" fill={accepted ? green : blue}
      fontSize={26} fontWeight={700}>
      {accepted ? 'All requirements passed — loop ends' : 'Repeat until every condition is met'}
    </text>
  </svg>;
};
