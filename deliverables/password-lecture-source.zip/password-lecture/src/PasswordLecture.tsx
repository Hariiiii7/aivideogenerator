import React from 'react';
import {AbsoluteFill, OffthreadVideo, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {PasswordFlow} from './PasswordFlow';

export type PasswordLectureProps = {
  source: string;
  frames: number;
  region: {x: number; y: number; width: number; height: number};
};
const blue = '#126298';
const teal = '#008c95';
const green = '#177c53';
const red = '#b53a4b';
const rules = ['Minimum 8 characters', 'Uppercase letter', 'Lowercase letter', 'Special symbol', 'Number'];
const stages = [0, 10, 27.8, 35, 46, 60.7, 67];
const reveals = [10, 15, 17.5, 19.5, 21];
const examples = ['', '', 'Ab1@xyz', 'ABCDEFGH', 'Abcd@123'];
const passes = [[], [], [false, true, true, true, true], [true, true, false, false, false], [true, true, true, true, true]];
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const Card: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => <div style={{backgroundColor: '#ffffffed', border: '2px solid #deebf2', borderRadius: 24, boxShadow: '0 8px 30px #16436208', ...style}}>{children}</div>;
const Check = ({color = green}: {color?: string}) => <svg width="28" height="28" viewBox="0 0 28 28"><path d="M5 14l6 6L24 7" fill="none" stroke={color} strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" /></svg>;

export const PasswordLecture: React.FC<PasswordLectureProps> = ({source, region}) => {
  const frame = useCurrentFrame();
  const t = frame / 30;
  const stage = stages.reduce((s, start, i) => t >= start ? i : s, 0);
  const age = t - stages[stage];
  const enter = interpolate(age, [0, .32], [0, 1], clamp);
  const next = stages[stage + 1];
  const leave = next === undefined ? 1 : interpolate(t, [next - .15, next], [1, 0], clamp);
  const scale = Math.min(region.width / 1040, region.height / 760);
  const titles = ['Create an email account', 'A strong password needs…', 'Too short', 'Length alone is not enough', 'All five rules satisfied', 'Password accepted', 'Keep trying until valid'];
  const subtitles = ['Start with a secure password.', 'Every requirement must be satisfied.', 'One missing character keeps this password invalid.', 'Each requirement is checked separately.', 'This password meets every condition.', 'The account can now be created.', 'A while loop repeats until the condition is satisfied.'];
  const example = examples[stage] || '';
  const typed = Math.min(8, Math.floor(Math.max(0, t - 2.5) * 2));
  return <AbsoluteFill>
    <OffthreadVideo src={staticFile(source)} style={{width: '100%', height: '100%', objectFit: 'contain'}} />
    <div style={{position: 'absolute', left: region.x, top: region.y, width: region.width, height: region.height, overflow: 'hidden'}}>
      <div style={{width: 1040, height: 760, transformOrigin: 'top left', transform: `scale(${scale})`, fontFamily: 'Arial, sans-serif', color: '#203e55', boxSizing: 'border-box', padding: '18px 12px'}}>
        <div style={{display: 'flex', gap: 12, alignItems: 'center', color: teal, fontSize: 20, fontWeight: 700, letterSpacing: 2.8}}>
          <svg width="28" height="30" viewBox="0 0 28 30"><path d="M7 12V8a7 7 0 0114 0v4M4 12h20v16H4z" fill="none" stroke={teal} strokeWidth="2.5" strokeLinejoin="round" /></svg>
          PASSWORD VALIDATION
        </div>
        <div style={{opacity: enter * leave, transform: `translateY(${(1-enter)*12}px)`}}>
          <h1 style={{fontSize: 43, color: blue, letterSpacing: -1, margin: '20px 0 12px'}}>{titles[stage]}</h1>
          <p style={{fontSize: 25, margin: '0 0 32px', color: '#56758b'}}>{subtitles[stage]}</p>
          {stage === 0 && <Card style={{padding: '30px 36px', width: 820, boxSizing: 'border-box'}}>
            <div style={{fontSize: 24, marginBottom: 12, fontWeight: 700}}>Email address</div>
            <div style={{border: '2px solid #d9e6ee', borderRadius: 12, padding: '16px 20px', fontSize: 28, color: '#678195'}}>student@example.com</div>
            <div style={{fontSize: 24, margin: '26px 0 12px', fontWeight: 700, color: blue}}>Password <span style={{fontSize: 20, color: teal, fontWeight: 400}}>Required</span></div>
            <div style={{border: `3px solid ${teal}`, borderRadius: 12, padding: '16px 20px', fontSize: 38, color: blue, boxShadow: '0 0 0 5px #e5f6f7', height: 82, display: 'flex', alignItems: 'center', lineHeight: 1, letterSpacing: 5}}>{'•'.repeat(typed)}<span style={{opacity: Math.sin(t * 5) > 0 ? 1 : 0, fontWeight: 400, letterSpacing: 0}}>│</span></div>
            <div style={{fontSize: 24, marginTop: 28, color: teal, display: 'flex', gap: 10, alignItems: 'center'}}><Check color={teal} /> Follow every password requirement</div>
          </Card>}
          {stage >= 1 && stage <= 4 && <div style={{display: 'flex', gap: 26, alignItems: 'stretch'}}>
            <Card style={{padding: 26, width: 388, boxSizing: 'border-box', flexShrink: 0}}>
              <div style={{color: '#6a8496', fontSize: 19, fontWeight: 700, letterSpacing: 1.6, marginBottom: 22}}>PASSWORD EXAMPLE</div>
              <div style={{fontSize: 40, fontFamily: 'monospace', letterSpacing: .5, color: blue, backgroundColor: '#eff7fc', border: '1px solid #d3e5f1', borderRadius: 14, padding: '20px 14px', textAlign: 'center'}}>{example || '••••••••'}</div>
              <div style={{display: 'flex', gap: 7, marginTop: 24}}>{Array.from({length: 8}, (_, i) => <div key={i} style={{height: 7, flex: 1, borderRadius: 5, backgroundColor: stage === 1 ? '#c9e4ed' : i < example.length ? stage === 2 ? '#d9939e' : teal : '#e2e9ed'}} />)}</div>
              <p style={{fontSize: 23, color: stage === 2 ? red : '#58788c', margin: '14px 0 32px'}}>{stage === 1 ? 'At least 8 characters' : `${example.length} characters`}</p>
              <div style={{borderRadius: 12, padding: '16px 14px', fontSize: 24, lineHeight: 1.45, fontWeight: 700, color: stage === 4 ? green : stage === 1 ? blue : red, backgroundColor: stage === 4 ? '#e9f8f0' : stage === 1 ? '#eff7fc' : '#fff1f2'}}>{stage === 1 ? 'All five rules matter' : stage === 2 ? 'Add at least one more character' : stage === 3 ? 'Three requirements are still missing' : 'Ready to create your account'}</div>
            </Card>
            <Card style={{padding: '24px 26px', flex: 1}}>
              <div style={{fontSize: 19, color: '#6a8496', letterSpacing: 1.6, fontWeight: 700, marginBottom: 18}}>REQUIREMENTS</div>
              {rules.map((rule, i) => {
                const reveal = stage === 1 ? interpolate(t, [reveals[i], reveals[i]+.4], [0, 1], clamp) : 1;
                const checked = stage >= 2;
                const ok = passes[stage]?.[i];
                const tick = stage === 4 ? interpolate(age, [.12+i*.14, .38+i*.14], [0, 1], clamp) : 1;
                const color = checked ? ok ? green : red : teal;
                return <div key={rule} style={{display: 'flex', alignItems: 'center', gap: 14, fontSize: 26, height: 67, opacity: reveal, transform: `translateX(${(1-reveal)*15}px)`, borderBottom: i === 4 ? undefined : '1px solid #edf2f5'}}>
                  <span style={{borderRadius: '50%', width: 40, height: 40, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, backgroundColor: checked ? ok ? '#e1f4e9' : '#ffedf0' : '#e6f4f7', color, fontWeight: 700, opacity: tick, transform: `scale(${.8+.2*tick})`}}>{checked ? ok ? <Check /> : '×' : '•'}</span>
                  <span style={{color, whiteSpace: 'nowrap'}}>{rule}</span>
                </div>;
              })}
            </Card>
          </div>}
          {stage === 5 && <Card style={{backgroundColor: '#f3fcf8', borderColor: '#c9e8da', textAlign: 'center', padding: '44px 20px', width: 860, boxSizing: 'border-box'}}>
            <div style={{width: 112, height: 112, margin: '0 auto 26px', borderRadius: '50%', backgroundColor: '#d9f2e5', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${interpolate(age, [0,.45], [.7,1], clamp)})`}}><svg width="66" height="66" viewBox="0 0 66 66"><path d="M12 34l14 14L56 18" fill="none" stroke={green} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="90" strokeDashoffset={90*(1-interpolate(age,[.15,.7],[0,1],clamp))} /></svg></div>
            <div style={{fontSize: 43, color: green, fontWeight: 700}}>Password accepted</div>
            <p style={{fontSize: 27, color: '#4a7b65'}}>All five requirements passed.</p>
            <div style={{fontSize: 32, fontFamily: 'monospace', color: blue}}>Abcd@123</div>
          </Card>}
          {stage === 6 && <PasswordFlow seconds={t-67} />}
        </div>
      </div>
    </div>
  </AbsoluteFill>;
};
