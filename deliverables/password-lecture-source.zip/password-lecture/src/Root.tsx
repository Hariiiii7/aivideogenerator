import {Composition} from 'remotion';
import {LectureIntro} from './LectureIntro';
import {PasswordLecture} from './PasswordLecture';

export const Root = () => (
  <>
  <Composition
    id="LectureIntro"
    component={LectureIntro}
    durationInFrames={150}
    fps={30}
    width={1280}
    height={720}
  />
  <Composition
    id="PasswordLecture"
    component={PasswordLecture}
    durationInFrames={2279}
    fps={30}
    width={1920}
    height={1080}
    defaultProps={{source: 'lecture-original.mp4', frames: 2279, region: {x: 150, y: 150, width: 1140, height: 800}}}
    calculateMetadata={({props}) => {
      if (props.region.width < 600 || props.region.height < 600) {
        throw new Error('Source layout must be inspected first. Supply a verified empty-white-space rectangle using scripts/prepare-lecture.mjs.');
      }
      return {durationInFrames: props.frames};
    }}
  />
  </>
);
