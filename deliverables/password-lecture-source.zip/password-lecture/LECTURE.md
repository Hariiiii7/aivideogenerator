# Password validation — full lecture animation

The complete composition uses the supplied compressed 1080p lecture as an
untrimmed base layer, with the original lecturer, background, logo, and Telugu
narration. Animations are confined to the clear region x150–1290, y150–950;
all nine representative stills were checked for readability and clearance.

## Reproduce the final MP4

Use Node.js 24, npm 11, Chromium, and FFmpeg/ffprobe. From this directory:

```sh
npm ci --cache /tmp/npm-cache
npm run typecheck
npm run render:lecture
node scripts/verify-lecture.mjs
```

The output is `out/password-lecture-1080p.mp4`. Rendering uses four workers and
`/usr/bin/chromium`. Edit scripts/render-lecture.mjs to use a different browser
location or worker count on another machine. Remotion first renders the entire
2279-frame visual composition. FFmpeg then copies the original AAC narration
stream directly from the source, with no audio re-encoding, added music, gain
changes, cuts, or voiceover. The container duration matches the original
75.989 seconds; the original 30fps video track is 75.966667 seconds long.

The editable archive contains `public/lecture-original.mp4` and
`lecture-props.json`; no extra download or source preparation is needed.
Run `npm run dev` to edit in Remotion Studio. Select `PasswordLecture`; the verified placement and duration are the defaults.
To load explicit input props, launch Studio using
`npm run dev -- --props=lecture-props.json --no-open`.

## Editable sources

- src/PasswordLecture.tsx: signup, password examples, requirements, success,
  reveal timings, transitions, and visual style.
- src/PasswordFlow.tsx: animated input/validate/retry loop and accepted exit.
- src/Root.tsx: 1920x1080 composition at 30fps; duration from input props.
- lecture-props.json: source filename, frame count, and inspected safe rectangle.
- scripts/prepare-lecture.mjs: inspect a replacement source using ffprobe,
  require narration, and prepare props from its actual video duration.
- scripts/render-lecture.mjs: full render and original-audio remux.
- scripts/verify-lecture.mjs: dimensions, duration, frame count, AAC packet hash,
  and full decode checks. Writes out/verification.json.

The sample LectureIntro composition remains available separately. Its short
video is unrelated to the full PasswordLecture output.

## Timeline

| Time | Visual |
| --- | --- |
| 0–10s | Email signup with highlighted password field |
| 10–27.8s | Length, uppercase, lowercase, symbol, number revealed in order |
| 27.8–35s | Ab1@xyz: length fails; other requirements pass |
| 35–46s | ABCDEFGH: length/uppercase pass; remaining requirements fail |
| 46–60.7s | Abcd@123: every requirement turns green |
| 60.7–67s | Animated green check and Password accepted |
| 67s–end | Two input/validate/retry cycles, then the valid accepted exit |

Reveal times follow the supplied approximate transcript: minimum length10s,
uppercase15s, lowercase17.5s, symbol19.5s, number21s. No subtitles, replacement
lecturer, external media, music, or synthesized narration are added.
