import {execFileSync} from 'node:child_process';
import {copyFileSync, existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const [source, ...rectangle] = process.argv.slice(2);
if (!source || rectangle.length !== 4) throw new Error('Usage: node scripts/prepare-lecture.mjs /path/to/original.mp4 x y width height (verified empty white space in 1920x1080 coordinates)');
const [x,y,width,height] = rectangle.map(Number);
if (![x,y,width,height].every(Number.isFinite) || x < 0 || y < 0 || width < 600 || height < 600 || x + width > 1920 || y + height > 1080) throw new Error('Invalid safe region: use a verified rectangle within the frame, at least 600x600.');
const metadata = JSON.parse(execFileSync('ffprobe', ['-v','error','-show_streams','-show_format','-of','json',source], {encoding:'utf8'}));
if (!metadata.streams.some(s => s.codec_type === 'audio')) throw new Error('The source must contain the original narration audio.');
const duration = Number(metadata.format.duration);
const videoDuration = Number(metadata.streams.find(s => s.codec_type === 'video')?.duration || duration);
const frames = Math.round(videoDuration * 30);
if (!Number.isFinite(duration) || duration < 68) throw new Error('Expected the full lecture, at least 68 seconds long.');
mkdirSync('public', {recursive:true});
const target = resolve('public/lecture-original.mp4');
if (resolve(source) !== target) {
  if (existsSync(target)) throw new Error('Source already exists; refusing to overwrite it.');
  copyFileSync(source, target);
}
writeFileSync('lecture-props.json', JSON.stringify({source:'lecture-original.mp4',frames,region:{x,y,width,height}},null,2)+'\n');
console.log(`Prepared full ${duration}s source; ${frames} frames at 30 fps. Original narration is embedded in the source video.`);
