import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdir, readFile, stat, writeFile} from 'node:fs/promises';
import {dirname, join, relative} from 'node:path';
import {fileURLToPath} from 'node:url';

const runFile = promisify(execFile);
const projectRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const sourcePath = join(projectRoot, 'public/lecture-original.mp4');
const outputPath = join(projectRoot, 'out/password-lecture-1080p.mp4');
const reportPath = join(projectRoot, 'out/verification.json');
const started = Date.now();
const report = {
  success: false,
  checkedAt: new Date().toISOString(),
  source: relative(projectRoot, sourcePath),
  output: relative(projectRoot, outputPath),
  checks: [],
};

const run = (command, args) => runFile(command, args, {
  cwd: projectRoot,
  encoding: 'utf8',
  maxBuffer: 16 * 1024 * 1024,
  timeout: 45 * 60 * 1000,
});

const probe = async (path) => {
  const {stdout} = await run('ffprobe', [
    '-v', 'error', '-show_format', '-show_streams', '-of', 'json', path,
  ]);
  return JSON.parse(stdout);
};

const frameRate = (rate = '') => {
  const [numerator, denominator = '1'] = rate.split('/').map(Number);
  return numerator / denominator;
};

const check = (name, passed, actual, expected) => {
  report.checks.push({name, passed: Boolean(passed), actual, expected});
};

// The hash muxer receives copied AAC packets, so no audio decoding,
// re-encoding, ADTS headers, or container metadata affects this digest.
const audioPacketHash = async (path) => {
  const {stdout} = await run('ffmpeg', [
    '-nostdin', '-v', 'error', '-i', path,
    '-map', '0:a:0', '-c:a', 'copy', '-f', 'hash', '-hash', 'sha256', '-',
  ]);
  const match = stdout.trim().match(/^SHA256=([a-f0-9]{64})$/i);
  if (!match) throw new Error(`Unexpected FFmpeg audio hash output for ${relative(projectRoot, path)}.`);
  return match[1].toLowerCase();
};

try {
  const outputStat = await stat(outputPath);
  if (outputStat.size === 0) throw new Error('Rendered output exists but is empty.');
  const [sourceMetadata, outputMetadata, propsText] = await Promise.all([
    probe(sourcePath),
    probe(outputPath),
    readFile(join(projectRoot, 'lecture-props.json'), 'utf8'),
  ]);
  const props = JSON.parse(propsText);
  const video = outputMetadata.streams.find((stream) => stream.codec_type === 'video');
  const audio = outputMetadata.streams.find((stream) => stream.codec_type === 'audio');
  const sourceVideo = sourceMetadata.streams.find((stream) => stream.codec_type === 'video');
  const expectedFrames = Number(props.frames || sourceVideo?.nb_frames || 2279);
  const actualFrames = Number(video?.nb_frames);
  const sourceDuration = Number(sourceMetadata.format.duration);
  const outputDuration = Number(outputMetadata.format.duration);
  const durationDifference = Math.abs(outputDuration - sourceDuration);

  report.metadata = {source: sourceMetadata, output: outputMetadata};
  report.outputBytes = outputStat.size;
  check('video codec', video?.codec_name === 'h264', video?.codec_name, 'h264');
  check('video dimensions', video?.width === 1920 && video?.height === 1080,
    {width: video?.width, height: video?.height}, {width: 1920, height: 1080});
  check('video frame rate', frameRate(video?.avg_frame_rate) === 30 && frameRate(video?.r_frame_rate) === 30,
    {average: video?.avg_frame_rate, nominal: video?.r_frame_rate}, '30/1');
  check('video frame count', actualFrames === expectedFrames,
    actualFrames, expectedFrames);
  check('audio codec', audio?.codec_name === 'aac', audio?.codec_name, 'aac');
  check('audio sample rate', Number(audio?.sample_rate) === 48000,
    Number(audio?.sample_rate), 48000);
  check('stereo audio', audio?.channels === 2 && (!audio.channel_layout || audio.channel_layout === 'stereo'),
    {channels: audio?.channels, layout: audio?.channel_layout}, {channels: 2, layout: 'stereo'});
  check('original duration preserved', durationDifference <= 0.01,
    {sourceSeconds: sourceDuration, outputSeconds: outputDuration, differenceSeconds: durationDifference},
    'difference <= 0.01 seconds');

  const [sourceHash, outputHash] = await Promise.all([
    audioPacketHash(sourcePath), audioPacketHash(outputPath),
  ]);
  report.audioPacketHashes = {
    algorithm: 'SHA-256',
    method: 'FFmpeg stream-copy packet payload hash',
    source: sourceHash,
    output: outputHash,
    identical: sourceHash === outputHash,
  };
  check('original AAC packet payload preserved', sourceHash === outputHash, outputHash, sourceHash);

  const decodeStarted = Date.now();
  try {
    const {stderr} = await run('ffmpeg', [
      '-nostdin', '-v', 'error', '-xerror', '-i', outputPath,
      '-map', '0:v:0', '-map', '0:a:0', '-f', 'null', '-',
    ]);
    report.decode = {
      success: stderr.trim().length === 0,
      elapsedSeconds: (Date.now() - decodeStarted) / 1000,
      errors: stderr.trim(),
      scope: 'All video frames and audio packets',
    };
  } catch (error) {
    report.decode = {
      success: false,
      elapsedSeconds: (Date.now() - decodeStarted) / 1000,
      errors: error.stderr?.trim() || error.message,
      scope: 'All video frames and audio packets',
    };
  }
  check('complete video and audio decode', report.decode.success, report.decode.success, true);
  report.success = report.checks.every((entry) => entry.passed);
} catch (error) {
  report.error = error.stderr?.trim() || error.message;
} finally {
  report.elapsedSeconds = (Date.now() - started) / 1000;
  await mkdir(dirname(reportPath), {recursive: true});
  await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`);
  if (report.success) {
    console.log(`Verification passed: ${relative(projectRoot, reportPath)}`);
    console.log('1080p H.264, 30 fps, full duration, identical original AAC audio, and full decode verified.');
  } else {
    console.error(`Verification failed: ${relative(projectRoot, reportPath)}`);
    for (const entry of report.checks.filter((entry) => !entry.passed)) console.error(`- ${entry.name}`);
    if (report.error) console.error(report.error);
    process.exitCode = 1;
  }
}
