import {execFileSync} from 'node:child_process';
import {readFileSync, mkdirSync} from 'node:fs';
const props = JSON.parse(readFileSync('lecture-props.json', 'utf8'));
mkdirSync('out', {recursive:true});
execFileSync('node_modules/.bin/remotion', ['render', 'src/index.ts', 'PasswordLecture', 'out/password-lecture-render.mp4', '--props=lecture-props.json', '--codec=h264', '--audio-codec=aac', '--pixel-format=yuv420p', '--concurrency=4', '--browser-executable=/usr/bin/chromium'], {stdio:'inherit'});
// Preserve the original AAC narration bit for bit, with no added or re-encoded audio.
execFileSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-i', 'out/password-lecture-render.mp4', '-i', `public/${props.source}`, '-map', '0:v:0', '-map', '1:a:0', '-c', 'copy', '-map_metadata', '1', '-movflags', '+faststart', 'out/password-lecture-1080p.mp4'], {stdio:'inherit'});
console.log('Full video saved to out/password-lecture-1080p.mp4 with original AAC audio.');
